use std::ops::Deref;
use crate::filesystem::directory::Directory;
use crate::filesystem::file::{File, FileContent};

pub mod file;
pub mod directory;

pub struct FileSystem {
    root: Directory,
    current_directory: String,
}

impl FileSystem {
    pub fn new() -> Self {
        let root = Directory {
            name: String::from("/"),
            parent: None,
            files: Vec::new(),
            subdirectories: Vec::new(),
        };

        let current_directory = root.get_path().clone();

        FileSystem {
            root,
            current_directory
        }
    }

    pub fn get_mut_from_path(&mut self, path: String) -> Result<&mut Directory, &str> {
        if path.is_empty() {
            return self.get_mut_from_path(self.current_directory.clone());
        }

        if path.as_str() == "/" {
            return Ok(&mut self.root);
        }

        let components: Vec<&str> = path.split('/').filter(|&c| !c.is_empty()).collect();

        let mut current_dir = if self.current_directory == "/" {
            &mut self.root
        } else {
            self.get_mut_from_path(self.current_directory.clone())?
        };

        for component in components {
            let Some(dir) = current_dir.find_directory_mut(component) else {
                // failed to find directory
                return Err("Failed to get current directory");
            };

            current_dir = dir;
        }

        Ok(current_dir)
    }

    pub fn get_from_path(&self, path: String) -> Result<&Directory, &str> {
        if path.is_empty() {
            return self.get_from_path(self.current_directory.clone());
        }

        if path.as_str() == "/" {
            return Ok(&self.root);
        }

        let components: Vec<&str> = path.split('/').filter(|&c| !c.is_empty()).collect();

        let mut current_dir = if self.current_directory == "/" {
            &self.root
        } else {
            self.get_from_path(self.current_directory.clone())?
        };

        for component in components {
            let Some(dir) = current_dir.find_directory(component) else {
                return Err("Failed to find directory");
            };

            current_dir = dir;
        }

        Ok(current_dir)
    }

    pub fn get_parent(&self, dir: &Directory) -> Result<&Directory, &str> {
        let Some(parent) = dir.parent.clone() else {
            return Err("Root has no parent directory!");
        };

        let dir = self.get_from_path(parent);
        dir
    }

    pub fn get_mut_parent(&mut self, dir: &Directory) -> Result<&mut Directory, &str> {
        let Some(parent) = dir.parent.clone() else {
            return Err("Root has no parent directory!");
        };

        let dir = self.get_mut_from_path(parent);
        dir
    }

    pub fn get_pwd(&self) -> String {
        self.current_directory.clone()
    }

    pub fn cd(&mut self, path: &str) -> Result<(), &str> {
        if path == "/" {
            self.current_directory = String::from("/");
            return Ok(());
        }

        let cd = self.current_directory.clone();

        let new_cd = {
            let components: Vec<&str> = path.split('/').filter(|&c| !c.is_empty()).collect();

            let mut dir = if path.starts_with('/') {
                &self.root
            } else {
                self.get_from_path(cd)?
            };

            for component in components {
                if component == ".." {
                    dir = self.get_parent(dir)?;
                } else {
                    let found = dir.subdirectories.iter().find(|subdir| subdir.name == component);

                    if let Some(subdir) = found {
                        dir = &subdir;
                    } else {
                        return Err("Directory not found");
                    }
                }
            }

            dir.get_path().clone()
        };

        self.current_directory = new_cd;

        Ok(())
    }

    pub fn ls(&self) {
        println!("{}:", self.get_pwd());

        let Ok(current_dir) = self.get_from_path(self.current_directory.clone()) else {
            println!("Failed to get current directory from path!");
            return;
        };

        for x in 0..current_dir.subdirectories.len() {
            let subdir = &current_dir.subdirectories.get(x).unwrap();
            if x != &current_dir.subdirectories.len() - 1 || current_dir.files.len() != 0 {
                println!(" ├─📁 {}", subdir.name);
            } else {
                println!(" └─📁 {}", subdir.name);
            }
        }

        for x in 0..current_dir.files.len() {
            let file = &current_dir.files.get(x).unwrap();
            if x != &current_dir.files.len() - 1 {
                println!(" ├─📄 {}", file.name);
            } else {
                println!(" └─📄 {}", file.name);
            }
        }
    }

    pub fn mkdir(&mut self, path: &str) -> Result<(), String> {
        let components: Vec<&str> = path.split('/').filter(|&c| !c.is_empty()).collect();

        let mut current_dir = if path.starts_with('/') {
            &mut self.root
        } else {
            self.get_mut_from_path(self.current_directory.clone())?
        };

        // Handle the root directory
        if components.is_empty() {
            return Err("Specified path can not be empty!".to_string());
        }

        for component in components {
            let mut parent_path = current_dir.parent.clone().unwrap_or(String::from("/"));
            if current_dir.name != "/" {
                parent_path.push_str(current_dir.name.as_str());
                parent_path.push_str("/");
            }

            let dir = current_dir.make_subdir(component, parent_path)?;
            current_dir = dir;
        }

        Ok(())
    }

    pub fn touch<S: Into<String>>(&mut self, path: S, file: File) -> bool {
        let path_result = self.get_mut_from_path(path.into());
        let Ok(current_dir) = path_result else {
            return false;
        };
        current_dir.touch(file);
        true
    }

    fn separate_file_and_parent(path: String) -> Option<(String, String)> {
        if let Some(last_separator) = path.rfind('/') {
            Some((path[0..last_separator].to_string(), path[last_separator+1..path.len()].to_string()))
        } else {
            None
        }
    }

    fn get_file<S: Into<String>>(&mut self, path: S) -> Result<&File, &str> {
        let mut file_name = path.into();
        // get parent directory
        // todo: this does not handle .. right now
        let parent_dir = if file_name.contains("/") {
            let Some((parent, fname)) = Self::separate_file_and_parent(file_name) else {
                return Err("Failed to get parent directory of specified file.");
            };

            file_name = fname;
            self.get_from_path(parent)?
        } else {
            self.get_from_path(self.current_directory.clone())?
        };

        // get the file if it exists in the parent directory
        let Some(file) = parent_dir.find_file(file_name) else {
            return Err("File by that name does not exist!");
        };

        Ok(file)
    }

    pub fn run<S: Into<String>>(&mut self, path: S) -> Result<(), &str> {
        let file = self.get_file(path)?;

        let FileContent::Executable(run) = file.content else {
            return Err("This file is not executable!");
        };

        run();

        Ok(())
    }

    pub fn cat<S: Into<String>>(&mut self, path: S) -> Result<String, &str> {
        let file = self.get_file(path)?;

        let FileContent::Text(txt) = &file.content else {
            return Err("This file is not a text file and can not be read!");
        };

        Ok(txt.clone())
    }

    // no rm function, not needed for the game
}