use std::fmt::{Display, Formatter};
use crate::filesystem::file::File;

#[derive(Clone, Debug, PartialEq)]
pub struct Directory {
    pub name: String,
    pub parent: Option<String>,
    pub subdirectories: Vec<Directory>,
    pub files: Vec<File>,
}

impl Directory {
    pub fn get_path(&self) -> String {
        format!("{}{}", self.parent.clone().unwrap_or(String::new()), self.name)
    }

    pub fn find_directory(&self, name: &str) -> Option<&Directory> {
        self.subdirectories.iter().find(|subdir| {
            subdir.name == name
        })
    }

    pub fn find_directory_mut(&mut self, name: &str) -> Option<&mut Directory> {
        for dir in &mut self.subdirectories {
            if dir.name == name {
                return Some(dir);
            }
        }
        None
    }

    pub fn find_file(&self, name: String) -> Option<&File> {
        self.files.iter().find(|file| {
            file.name == name
        })
    }

    pub fn find_file_mut(&mut self, name: &str) -> Option<&mut File> {
        for f in &mut self.files {
            if f.name == name {
                return Some(f);
            }
        }
        return None;
    }

    pub fn touch(&mut self, file: File) {
        self.files.push(file);
    }
    pub fn make_subdir(&mut self, name: &str, parent_path: String) -> Result<&mut Directory, String> {
        let new_dir = Directory {
            name: name.to_string(),
            parent: Some(format!("{}", parent_path)),
            files: Vec::new(),
            subdirectories: Vec::new(),
        };

        if self.subdirectories.iter().any(|subdir| subdir.name == name) {
            // Directory with the same name already exists
            return Err(String::from("Directory already exists"));
        }

        self.subdirectories.push(new_dir);

        let index = self.subdirectories.len() -1;

        Ok(&mut self.subdirectories[index])
    }
}

impl Display for Directory {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "📁 {}", self.name)
    }
}