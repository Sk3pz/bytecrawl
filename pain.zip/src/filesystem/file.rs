use std::fmt::{Display, Formatter};

#[derive(Clone, Debug, PartialEq)]
pub enum FileContent {
    Text(String), // text files are currently read only
    Executable(fn() -> ()), // executables are not editable by users
    // todo: user editable script?
}

impl ToString for FileContent {
    fn to_string(&self) -> String {
        String::from(match self {
            FileContent::Text(_) => "TXT",
            FileContent::Executable(_) => "EXEC",
        })
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct File {
    pub name: String,
    pub content: FileContent,
}

impl Display for File {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(f, "🗎 {} {} {}", self.content.to_string(), self.content.to_string(), self.name)
    }
}