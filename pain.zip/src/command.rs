use crate::filesystem::FileSystem;

pub(crate) enum Command {
    CD { path: String },   // change "directories"
    LS,                   // list contents of current "directory"
    PWD,                  // display the current "directory"
    CLEAR,                // clear the screen
    EXIT,
    CAT { path: String },
    MKDIR { path: String },
    RUN { prgm: String }, // "run" a "program"
    // other cmd types go here
    INVALID,              // invalid command
}

impl Command {
    pub fn parse<S: Into<String>>(raw: S) -> Self {
        let input = &raw.into();
        let mut tokens: Vec<&str> = input.trim().split_whitespace().collect();

        if tokens.is_empty() {
            return Command::INVALID;
        }

        let cmd = tokens.remove(0);

        match cmd {
            "cd" if tokens.len() > 0 => {
                Command::CD {
                    path: tokens.join(" "),
                }
            }
            "ls" if tokens.len() == 0 => Command::LS,
            "pwd" if tokens.len() == 0 => Command::PWD,
            "clear" if tokens.len() == 0 => Command::CLEAR,
            "mkdir" if tokens.len() != 0 => {
                Command::MKDIR {
                    path: tokens.join(" ")
                }
            }
            "exit" if tokens.len() == 0 => Command::EXIT,
            "cat" if tokens.len() > 0 => {
                Command::CAT {
                    path: tokens.join(" "),
                }
            }
            _ if cmd.starts_with("./") => {
                let executable_name = cmd.to_string().replace("./", "");
                Command::RUN {
                    prgm: executable_name
                }
            }
            _ => Command::INVALID,
        }
    }

    pub fn execute(&self, fs: &mut FileSystem) -> Result<bool, String> {
        match self {
            Command::CD { path } => {
                fs.cd(path)?
            }
            Command::LS => {
                fs.ls()
            }
            Command::PWD => {
                println!("{}", fs.get_pwd());
            }
            Command::CLEAR => {
                println!("This command is not implemented.");
            }
            Command::CAT { path } => {
                let text = fs.cat(path)?;
                println!("{}:\n{}", path, text)
            }
            Command::MKDIR { path } => {
                fs.mkdir(path)?
            }
            Command::RUN { prgm } => {
                fs.run(prgm)?;
            }
            Command::EXIT => {
                return Ok(true);
            }
            Command::INVALID => {
                println!("Unknown command.");
            }
        }

        Ok(false)
    }
}