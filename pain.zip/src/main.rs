use crate::command::Command;
use crate::filesystem::file::{File, FileContent};
use crate::filesystem::FileSystem;

mod command;
mod filesystem;

fn prompt(pwd: String) -> String {
    better_term::read_input!("{}> ", pwd)
}

fn main() {
    let mut fs = FileSystem::new();

    // todo: populate the filesystem properly
    fs.mkdir("/test/test2/test").expect("failed to populate test directories");
    fs.mkdir("/test1/test2/test").expect("failed to populate test directories");
    fs.mkdir("/test2/test2/test").expect("failed to populate test directories");
    fs.touch("/", File {
        name: "Some File".to_string(),
        content: FileContent::Text(format!("This is a text file.")),
    });

    fs.touch("/test/", File {
        name: "runnable".to_string(),
        content: FileContent::Executable(|| {
            println!("You ran the file!");
        })
    });

    println!("Welcome to ByteCrawl! Type ls to get your bearings.");

    loop {
        let input = prompt(fs.get_pwd());
        // todo: detect ctrl+c?

        let cmd = Command::parse(input);

        let result = cmd.execute(&mut fs);

        if let Ok(exit) = result {
            if exit {
                break;
            }
        } else if let Err(e) = result {
            println!("{}", e);
        }
    }

    println!("Safely Exited.");
}
